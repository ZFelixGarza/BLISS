%% Main program for BLISS (Model for blue light irradiation of psoriatic skin )
% Z.C. F�lix Garza
% Last modified 16-12-16
% This script reproduces figure 5 and 6A of the manuscript titled 'A dynamic  
% model for prediction of psoriasis management by blue light irradiation'
%%
 clear all; close all;


%% Figure 5
% Input (treatment) parameters 
beginBL = 10; % Starting day of treatment
doseBL = 90;  % Dose used per treatment session
therI = 28;   % (days) Duration of daily treatment sessions
therII = 56;  % (days) Duration of 3 days per week treatment sessions

%% Initial conditions - Initial cell densities of all keratinocyte
% populations
%------------Healthy (h)---------//------------Diseased (d)----------------
%-----SC---TA--GA---SP---GC--CC-//-SC----TA-----GA-----SP----GC---CC-------
x0 = [362, 77, 61, 238, 119, 185, 6459, 32098, 20536, 79788, 0, 77633];

[tBL,xBL] = generateBLTreatedPsorSkin(x0,0,beginBL,doseBL,therI,therII); 
    % This function calls the needed subrutines to perform the simulations   
%% Plot the cell densities of all keratinocytes
generateCellDensityPlot(xBL,tBL)

%% Figure 6A
therTime = [0,0; 28, 0; 56, 0; 84, 0; 112, 0; 140, 0; 168, 0; 196, 0];

beginBL = 0;
doseBL = 90;
LPSI0 = 5.34;
PTotMLPSI(:,1) = [0, 4, 8, 12, 16, 20, 24, 28];
for i = 1:size(therTime,1)
    therI = therTime (i,1);
    therII = therTime(i,2); 
    x0 = [362, 77, 61, 238, 119, 185, 6459, 32098, 20536, 79788, 0, 77633];
    [tBL1,xBL1] = generateBLTreatedPsorSkin_piecewise_7dFirst(x0,0,beginBL,doseBL,therI,therII);
    PTotMLPSI(i,2) = LPSI0+(LPSI0*((sum(xBL1(end,:))-sum(xBL1(1,:)))/sum(xBL1(1,:))));
    [tBL2,xBL2] = generateBLTreatedPsorSkin_piecewise_3dFirst(x0,0,beginBL,doseBL,therI,therII);
    PTotMLPSI(i,3) = LPSI0+(LPSI0*((sum(xBL2(end,:))-sum(xBL2(1,:)))/sum(xBL2(1,:))));
end

figure;
scatter(PTotMLPSI(:,1), PTotMLPSI(:,2))
hold on 
scatter(PTotMLPSI(:,1), PTotMLPSI(:,3))
xlim([0 29]);
ylim([0 10]);
set(gca,'XTick',[0 4 8 12 16 20 24 28])
xlabel('Time (weeks)')
ylabel('Local Psoriasis Severity Index (LPSI)')