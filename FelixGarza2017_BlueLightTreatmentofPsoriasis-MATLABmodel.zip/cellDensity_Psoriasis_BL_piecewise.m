% Z.C. F�lix Garza
% Last modified 09-11-16
function [f] = cellDensity_Psoriasis_BL_piecewise(t,x,dose,apopF)
% This function computes the ODEs for a given system
% Returns:
% f: Column vector with odes for the given system

% Required:
% x: Species concentrations, [a, b, ... ].
% t: Time span
% dose: Blue light dose in Jcm-2
% apopF: factor affecting apoptosis of keratinocytes at high doses (>500 Jcm-2) of BL.

% Case 1: Only the proliferation rate of all proliferative keratinocytes is
% decreased.
%% State variables
Psc = x(1); % Stem cells
Pta = x(2); % TA cells
Pga = x(3); % Growth Arrested cells
Psp = x(4); % Spinous cells
Pgc = x(5); % Granular cells
Pcc = x(6); % Corneocytes 
Pscps = x(7); % Stem cells
Ptaps = x(8); % TA cells
Pgaps = x(9); % Growth Arrested cells
Pspps = x(10); % Spinous cells
Pgcps = x(11); % Granular cells
Pccps = x(12); % Corneocytes
%% Model parameters
aProl = 1;
% bProl = -0.005404;
bProl = -0.003404;
thetaBLprol = aProl*exp(bProl*dose);
% thetaBLprol = (0.05033*exp(-44.32*dose)+0.9497*exp(-.4952*dose));

% Healthy skin  
Pscmax = 4500; % Pscmax (mm^2)SC growth capacity pmax 
gamma1h = 3.30E-3; % Gamma1h (d^-1) Nominal SC self-proliferation rate 
                   % constant at homeostasis 
k1sh = 1.64E-3; % k1sh (d^-1) Nominal symmetric SC division rate constant 
                % at homeostasis
k1ah = 1.31E-2; % k1ah (d^-1) Nominal asymmetric SC division rate constant 
                % at homeostasis
gamma2 = 1.40E-2; % Gamma2 (d^-1) TA cell self-proliferation rate constant
k1s = 0; % k1s
k1a = 0; % k1a 
k2s = 1.73E-2;% k2s 
k2a = 1.38E-1; % k2a 
k3 = 2.16E-1; % k3 
k4 = 5.56E-2;% k4 
k5 = 1.11E-1;% k5 
Kp = 6; % Kp (mm^-2 d^-1) Maximum immune response rate Kp 
Ka = 380; % (mm^-2) Immune half-activation psoriatic SC density
alpha = 7.14E-2; % alpha  (d^-1) CC cell desquamation rate constant
km1 = 1.00E-6; % km1      (d^-1) Backconversion rate constant from TA to SC
km2 = 1.00E-6; % km2      (d^-1) Backconversion rate constant from GA to TA
omega = 100; % Omega  Maximum fold increase of SC proliferation rate 
n = 3; % n  Steepness SC proliferation rate regulation by TA population 
AIh = 0.0012; % AIh  Normal epidermal apoptosis index 
beta1h = (AIh*k1sh)/(1-AIh); % Beta1h  Apoptosis rate in homeostasis for SC 
beta1 = (AIh*k1sh)/(1-AIh);
beta2 = (AIh*k2s)/(1-AIh);
beta3 = (AIh*k3)/(1-AIh);
beta4 = (AIh*k4)/(1-AIh);
beta5 = (AIh*k5)/(1-AIh); 

Psch = Pscmax*(1-((1/gamma1h)*(k1sh + beta1h - ((km1*(k1ah + (k1sh*2)))/...
   (km1 + k2s + beta2 - gamma2 - ((km2*(k2a + 2*k2s))/...
   (km2 + k3 + beta3)))))));
Ptah = ((k1ah + (2*k1sh))/(km1 + k2s +beta2 - gamma2 -((km2*(k2a+...
    (2*k2s)))/(km2 + k3 + beta3))))*Psch;

% Psoriatic skin 
lambda = 3.5; % Lambda  Fold change of SC growth capacity in psoriasis 
AId = 0.00035; % AId  Psoriatic epidermal apoptosis index 
rhoSC = 4; % Fold change of SC 
rhoTA = 4; % Fold change of TA
rhoTr = 5; % Fold change of Transtit
rhoDe = 4; % Fold change of Desquamation
kps1s = rhoSC*k1sh; % 
kps1a = rhoSC* k1ah;   % 
kps2s = rhoTA*k2s;  % 
kps2a = rhoTA*k2a;  % 
kps3 =  rhoTr*k3; % 
kps4 =  rhoTr*k4;  % 
gamma1ps = rhoSC* gamma1h; % 
kmps1 = km1; %
kmps2 = km2; %
gamma2ps = rhoTA* gamma2*thetaBLprol; % 
betaps1 = (AId*k1sh*rhoSC)/(1-AId); %
betaps2 = (AId*kps2s)/(1-AId); %
betaps3 = (AId*kps3)/(1-AId); %
betaps4 = (AId*kps4)/(1-AId); %
alphaps = rhoDe* alpha; % 

% Variable parameters
gamma1 = (omega/(1 + ((omega - 1)*(((Pta + Ptaps)/Ptah)^n))))*gamma1h; % (d^-1) Nominal SC self-proliferation rate constant
k1s = (omega/(1 + ((omega - 1)*(((Pta + Ptaps)/Ptah)^n))))*k1sh; % (d^-1) Nominal symmetric SC division rate constant
k1a = (omega/(1 + ((omega - 1)*(((Pta + Ptaps)/Ptah)^n))))*k1ah; % (d^-1) Nominal asymmetric SC division rate constant

%% This only applies when looking at just healthy cells
% gamma1 = (omega/(1 + ((omega - 1)*(((Pta)/Ptah)^n))))*gamma1h; % (d^-1) Nominal SC self-proliferation rate constant
% k1s = (omega/(1 + ((omega - 1)*(((Pta)/Ptah)^n))))*k1sh; % (d^-1) Nominal symmetric SC division rate constant
% k1a = (omega/(1 + ((omega - 1)*(((Pta)/Ptah)^n))))*k1ah; % (d^-1) Nominal asymmetric SC division rate constant
%% Set activation of immune systemgammaBL
if Pscps >= (.10*Psc)  
    Ka = (((3)^(1/2))*Psch)/10;
end

%% ODEs
% Normal skin and psoriatic skin
    f(1) = (((gamma1*(thetaBLprol))*(1-((Psc + (Pscps/lambda))/Pscmax)))- k1s - beta1- apopF)...
        *Psc+ (km1*Pta);
%     f(1) = (((gamma1*(thetaBLprol))*(1-((Psc)/Pscmax)))- k1s - beta1- apopF)...
%         *Psc+ (km1*Pta);
    f(2) = ((2*k1s +k1a)*Psc) + ((gamma2*thetaBLprol -k2s-beta2-km1 - apopF)*Pta)+km2*Pga; 
    f(3) = ((2*k2s +k2a)*Pta) - ((k3 + beta3 + km2 + apopF)*Pga);
    f(4) = k3*Pga - (k4 + beta4 + apopF)*Psp;
    f(5) = k4*Psp - (k5 + beta5 + apopF)*Pgc;
    f(6) = k5*Pgc - (alpha + apopF)*Pcc; 
    f(7) = (((gamma1ps*thetaBLprol)*(1-((Psc + Pscps)/(lambda*Pscmax))))- kps1s - ...
        betaps1 - apopF)*Pscps - (((Kp*(Pscps^2))/(Ka^2 + Pscps^2))) + kmps1*Ptaps;
    f(8) = ((2*kps1s + kps1a)*Pscps) + ((gamma2ps*thetaBLprol - kps2s - betaps2 - ...
        kmps1 - apopF)*Ptaps) + kmps2*Pgaps; 
    f(9) = ((2*kps2s +kps2a)*Ptaps) - ((kps3 + betaps3 + kmps2 + apopF)*Pgaps);
    f(10) = kps3*Pgaps - (kps4 + betaps4 + apopF)*Pspps;
    f(11) = 0;
    f(12) = kps4*Pspps - (alphaps + apopF)*Pccps; 

f = f(:); %Output needs to be a column vector
