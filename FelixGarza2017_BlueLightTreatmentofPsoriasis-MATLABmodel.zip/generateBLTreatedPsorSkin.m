% Z.C. F�lix Garza
% Last modified 16-12-16
function [tTot,xTot] = generateBLTreatedPsorSkin(x0,t0,beginBL,fluenceBL, therI, therII)
% Runs the kinetic model in three steps. First it computes the cell 
% densities of all keratinocyte populations in the lesional skin until 
% beginBL is reached. Next, at time tStartTherapy, the  treatment  with  
% blue  light  begins  and  the specified fluence of blue light (fluenceBL)
% is shined on the epidermis according to parameters therI and therII. The 
% response to the treatment  is  simulated,  and  can  result  in  
% non-lesional  skin.  
% * The simulated treatment accounts for continuous wave irradiation
%%
%% Creation of local variables
tStartTherapy = t0+beginBL;      % Timepoint at which the treatment starts. 
therFirst = therI;               % (days)
therSecond = therII;             % (days)
xTot = []; tTot = []; % Initialize variable for total cell densities (xTot)   
                      % and total time (tTot) 
xB = []; tB = [];     % Initialize variable for cell densities (xB) and time  
                      % (tB) in the before treatment section 
xDI = []; tDI = [];   % Initialize variable for cell densities (xDI) and time  
                      % (tDI) in the first part of the treatment
xDII = []; tDII = []; % Initialize variable for cell densities (xDII) and time  
                      % (tDII) in the second part of the treatment
xA = []; tA = [];     % Initialize variable for cell densities (xA) and time  
                      % (tA) after treatment
% Set the apoptosis factor of blue light for treatment sections of
% simulation
if fluenceBL >= 500 && fluenceBL<750 % For fluences of 500-750 Jcm-2 the 
    apopFBL = 0.039;                 % apoptosis factor has a value of 0.039
else if fluenceBL>=750               % For fluences above 750 Jcm-2 the
            apopFBL = 0.05;          % apoptosis factor has a value of 0.05
    else                             % For fluences below 500 Jcm-2 the
            apopFBL = 0;             % apoptosis factor has a value of 0
     end
end
%% Integrate ODEs
options = odeset('RelTol', 1e-9, 'AbsTol', 1e-9); % Settings for ODE solver 

%% Before blue light treatment
xB0 = x0;                          % Set initial cell densities
tspan = [t0 tStartTherapy-0.01];   % Set time range
fluence = 0;                       % (Jcm-2) Set fluence
apopF = 0;                         % Set the apoptosis factor of blue light

[tB,xB] = ode15s(@(t,x)cellDensity_Psoriasis_BL_piecewise(t,x,fluence,apopF),tspan,xB0, options);
tTot = tB;    % Add timepoints of this section to total time array                        
xTot = xB;    % Add timepoints of this section to total cell density matrix 

%% During blue light treatment 
st = [1 0.579, 0.790, 0.4696, 0.728]; %energy absorption per skin type

if therI > 0 || therII > 0% Check if timepoint corresponds to the range of
                          % the treatment
    if therI > 0          % Check if the tretament includes daily treatment
        tspan = [tTot(end) tTot(end)+therFirst];    % Set time range
        fluence = fluenceBL*st(2); %(Jcm-2)         % Set absorbed fluence
        [tDI,xDI] = ode15s(@(t,x)cellDensity_Psoriasis_BL_piecewise(t,x,fluence,apopFBL),tspan,xTot(end,:), options);
        tTot = [tTot;tDI]; % Add timepoints of this section to total time array 
        xTot = [xTot;xDI]; % Add timepoints of this section to total cell density matrix
    end
    
    if therII > 0 % Check if the tretament includes every-other-day treatment
        therDay = tTot(end):2.5:tTot(end)+therSecond+2; % Specify when the treatment takes place
        
        for i= tTot(end):0.5: tTot(end)+ therSecond +2  % Set fluence of treatment days
            flag = 0;
            for j = 1:length(therDay)-1
                if i >= therDay(j) && i <therDay(j+1) - 0.5
                    flag = 1;
                end
            end
            if flag == 1
                fluence = fluenceBL*st(2); %(J/cm2)
            else 
                fluence = 0;
            end

            tspan  = [i i+0.5];
            [tTemp,xTemp] = ode15s(@(t,x) cellDensity_Psoriasis_BL_piecewise(t,x,fluence,apopFBL),tspan,xTot(end,:),options);
            tTot = [tTot;tTemp]; % Add timepoints of this section to total time array 
            xTot = [xTot;xTemp]; % Add timepoints of this section to total cell density matrix
            tTemp = [];          % Reset temp variable
            xTemp = [];          % Reset temp variable
        end
    end
end

%% After treatment period
tspan = [tTot(end) tTot(end)+1500]; % Set time range
fluence = 0;                        % (Jcm-2) Set fluence back to zero

[tA,xA] = ode15s(@(t,x)cellDensity_Psoriasis_BL_piecewise(t,x,fluence,apopF),tspan,xTot(end,:),options);
xTot = [xTot;xA];    % Add timepoints of this section to total time array 
tTot = [tTot;tA];    % Add timepoints of this section to total cell density matrix
end
