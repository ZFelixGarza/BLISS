%% BL in pieces
function [tTot,xTot] = generateBLTreatedPsorSkin_piecewise_3dFirst(x0,t0,beginBL,fluenceBL, therI, therII)
% Runs the kinetic model with the given parameter structure p. Runs in 2 
% steps: first the lesional skin is generated. Next, at time tStartTherapy, 
% the  treatment  with  blue  light  begins  and  fluence BL is shined on the 
% epidermis according to blTherPart1 and blTherPart2. The  response to the 
% treatment  is  simulated,  and  can  result  in  non-lesional  skin.  
%%
tStartTherapy = t0+beginBL;
therFirst = therI; % days -> 4 weeks
therSecond = therII; % days -> 8 weeks

if fluenceBL >= 500 && fluenceBL<750 
    apopFBL = 0.039;
else if fluenceBL>=750
            apopFBL = 0.05;
     else
            apopFBL = 0;
     end
end
%% Run model in CW
xB = []; xDI = []; xDII = []; xA = []; 
tB = []; tDI = []; tDII = []; tA = []; 
options = odeset('RelTol', 1e-9, 'AbsTol', 1e-9);

% Integrate ODEs:
apopFBL = 0;
tTot = t0;
xTot = x0;

% Blue light therapy 
st = [1 0.579, 0.790, 0.4696, 0.728]; %energy absorption per skin type

%% BLT effect 
if therI > 0 || therII > 0
    if therI > 0 
        therDay = tTot(end):2.5:tTot(end)+therFirst+2;
        
        for i= tTot(end):0.5: tTot(end)+ therFirst +2
            flag = 0;
            for j = 1:length(therDay)-1
                if i >= therDay(j) && i <therDay(j+1) - 0.5
                    flag = 1;
                end
            end
            if flag == 1
                fluence = fluenceBL*st(2); %(J/cm2)
            else 
                fluence = 0;
            end

            tspan  = [i i+0.5];
            [tTemp,xTemp] = ode15s(@(t,x) cellDensity_Psoriasis_BL_piecewise(t,x,fluence,apopFBL),tspan,xTot(end,:),options);
            tTot = [tTot;tTemp];
            xTot = [xTot;xTemp];
            tTemp = [];
            xTemp = [];
        end
    end
    
    if therII > 0 
        tspan = [tTot(end) tTot(end)+therSecond];
        fluence = fluenceBL*st(2); %(J/cm2)
        [tDI,xDI] = ode15s(@(t,x)cellDensity_Psoriasis_BL_piecewise(t,x,fluence,apopFBL),tspan,xTot(end,:), options);
        tTot = [tTot;tDI];
        xTot = [xTot;xDI];
    end
end

xTot = [xTot;xA];
tTot = [tTot;tA];
end
